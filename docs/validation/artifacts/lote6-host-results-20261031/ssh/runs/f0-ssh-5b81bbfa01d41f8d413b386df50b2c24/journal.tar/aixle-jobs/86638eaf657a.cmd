set -eu
cd /lab/home/source
git fetch /lab/home/307a8ea7869186d5c808d6bb2664513296d1930291ea9643014bf289e5099610.bundle HEAD
git checkout --detach c7455f7f0c4d833a9b788f0c46d5ae37db5f130f
echo execution >> /lab/home/execution-counter
sleep 2
sh test.sh
observed=$(git rev-parse HEAD)
test "$observed" = c7455f7f0c4d833a9b788f0c46d5ae37db5f130f
printf '
---aixle_job_result---
observed_sha=%s
artifact_sha256=307a8ea7869186d5c808d6bb2664513296d1930291ea9643014bf289e5099610
' "$observed"

